#include "engine/log/log.h"

Log * Log::_Instance = NULL;