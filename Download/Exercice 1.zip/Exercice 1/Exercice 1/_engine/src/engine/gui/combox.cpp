#include "combox.h"

void OnClickComboBox(GUIBouton * bouton)
{
	return;
}
