#include "engine/render/renderer.h" 

NYRenderer * NYRenderer::_Me = NULL;
float NYRenderer::_DeltaTime = 0;
float NYRenderer::_DeltaTimeCumul = 0;