#include "tex_manager.h"

NYTexManager * NYTexManager::_Instance = NULL;